import { Component, OnInit } from '@angular/core';
import { GroupsService } from '../groups.service';

export interface Group {
  name: string;
  description: string;
  avatar_url: string;
}

@Component({
  selector: 'app-groups',
  templateUrl: './groups.page.html',
  styleUrls: ['./groups.page.scss'],
})
export class GroupsPage implements OnInit {
  public groups: Group[] = [];
  constructor(public groupService: GroupsService) { }

  ngOnInit() {

    this.groupService.all().then(response =>{
      this.groups = response;
    })
  }

}