import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

export interface Group{
  name: string;
  description: string;
  avatar_url: string;
}

@Injectable({
  providedIn: 'root'
})

export class GroupsService {

  public api: string = 'https://fake-tweets-api.herokuapp.com/posts'

  constructor(public httpClient: HttpClient) { }

  public all(): Promise<Group[]>{

    return this.httpClient.get<Group[]>(this.api).toPromise();
  }
}